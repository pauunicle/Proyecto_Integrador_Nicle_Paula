package com.portfolio.NiclePaula;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NiclePaulaApplicationTests {

	@Test
	void contextLoads() {
	}

}
