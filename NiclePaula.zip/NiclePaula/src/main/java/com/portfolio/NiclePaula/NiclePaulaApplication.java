package com.portfolio.NiclePaula;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NiclePaulaApplication {

	public static void main(String[] args) {
		SpringApplication.run(NiclePaulaApplication.class, args);
	}

}
